<?php
/*
Plugin Name: WooCommerce and 1C:Enterprise Data Exchange
Version: 1.0.0
Description: Provides data exchange between WooCommerce and 1C:Enterprise 8. Trade Management.
Author: Igor Melnyk
Author URI: mailto:igormelnykit@gmail.com
Plugin URI: https://github.com/igormelnykit/woocommerce-1c
License: GPL v3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Text Domain: woocommerce-1c
Domain Path: /languages
*/

if (!defined('ABSPATH')) exit;

require_once ABSPATH . "wp-admin/includes/plugin.php";

if (!defined('__DIR__')) define('__DIR__', dirname(__FILE__));

define('WC1C_PLUGIN_DIR', __DIR__ . '/');
define('WC1C_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('WC1C_PLUGIN_BASEDIR', dirname(WC1C_PLUGIN_BASENAME) . '/');
$upload_dir = wp_upload_dir();
define('WC1C_DATA_DIR', "{$upload_dir['basedir']}/woocommerce-1c/");

function wc1c_init() {
  if (!is_plugin_active("woocommerce/woocommerce.php")) {
    function wc1c_woocommerce_admin_notices() {
      $plugin_data = get_plugin_data(__FILE__);
      $message = sprintf(__("Plugin <strong>%s</strong> requires plugin <strong>WooCommerce</strong> to be installed and activated.", 'woocommerce-1c'), $plugin_data['Name']);
      printf('<div class="updated"><p>%s</p></div>', $message);
    }
    add_action('admin_notices', 'wc1c_woocommerce_admin_notices');
  }
}
add_action('init', 'wc1c_init');

function wc1c_load_textdomain() {
  $locale = determine_locale();
  $mofile = WC1C_PLUGIN_DIR . 'languages/woocommerce-1c-' . $locale . '.mo';
  
  if (file_exists($mofile)) {
    load_textdomain('woocommerce-1c', $mofile);
  }
}
add_action('init', 'wc1c_load_textdomain');

function wc1c_activate() {
  global $wpdb;

  $index_table_names = array(
    $wpdb->postmeta,
    $wpdb->termmeta,
    $wpdb->usermeta,
  );
  foreach ($index_table_names as $index_table_name) {
    $index_name = 'wc1c_meta_key_meta_value';
    $result = $wpdb->get_var("SHOW INDEX FROM $index_table_name WHERE Key_name = '$index_name';");
    if ($result) continue;

    $wpdb->query("ALTER TABLE $index_table_name ADD INDEX $index_name (meta_key, meta_value(36))");
  }

  if (!is_dir(WC1C_DATA_DIR)) mkdir(WC1C_DATA_DIR);
  file_put_contents(WC1C_DATA_DIR . ".htaccess", "Deny from all");
  file_put_contents(WC1C_DATA_DIR . "index.html", '');

  wc1c_add_rewrite_rules();
  flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'wc1c_activate');

register_deactivation_hook(__FILE__, 'flush_rewrite_rules');

function wc1c_add_rewrite_rules() {
  add_rewrite_rule("wc1c/exchange", "index.php?wc1c=exchange", 'top');
  add_rewrite_rule("wc1c/clean", "index.php?wc1c=clean");
}

function wc1c_delete_term($term_id, $tt_id, $taxonomy, $deleted_term) {
  global $wpdb;

  if ($taxonomy != 'product_cat' && strpos($taxonomy, 'pa_') !== 0) return;

  $wpdb->delete($wpdb->termmeta, array('term_id' => $term_id));
  if (function_exists('wc1c_check_wpdb_error')) wc1c_check_wpdb_error();
}
add_action('delete_term', 'wc1c_delete_term', 10, 4);

function wc1c_woocommerce_attribute_by_id($attribute_id) {
  global $wpdb;

  $cache_key = "wc1c_woocomerce_attribute_by_id-$attribute_id";
  $attribute = wp_cache_get($cache_key);
  if ($attribute === false) {
    $attribute = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_id = %d", $attribute_id), ARRAY_A);
    if (function_exists('wc1c_check_wpdb_error')) wc1c_check_wpdb_error();

    if ($attribute) {
      $attribute['taxonomy'] = wc_attribute_taxonomy_name($attribute['attribute_name']);

      wp_cache_set($cache_key, $attribute);
    }
  }

  return $attribute;
}

function wc1c_delete_woocommerce_attribute($attribute_id) {
  global $wpdb;

  $attribute = wc1c_woocommerce_attribute_by_id($attribute_id);

  if (!$attribute) return false;

  delete_option("{$attribute['taxonomy']}_children");

  $terms = get_terms($attribute['taxonomy'], "hide_empty=0");
  foreach ($terms as $term) {
    wp_delete_term($term->term_id, $attribute['taxonomy']);
  }

  $wpdb->delete("{$wpdb->prefix}woocommerce_attribute_taxonomies", compact('attribute_id'));
  if (function_exists('wc1c_check_wpdb_error')) wc1c_check_wpdb_error();
}

function wc1c_parse_decimal($number) {
  $number = str_replace(array(',', ' '), array('.', ''), $number);

  return (float) $number;
}

require_once WC1C_PLUGIN_DIR . "admin.php";
require_once WC1C_PLUGIN_DIR . "exchange.php";
