<?php
/**
 * HPOS Compatibility Functions
 */

if (!defined('ABSPATH')) exit;

/**
 * Get orders with HPOS compatibility
 */
function wc1c_get_orders($args = array()) {
    if (function_exists('wc_get_orders')) {
        return wc_get_orders($args);
    }
    
    // Fallback to old method
    $post_args = array(
        'post_type' => 'shop_order',
        'post_status' => isset($args['status']) ? $args['status'] : 'any',
        'numberposts' => isset($args['limit']) ? $args['limit'] : -1,
    );
    
    if (isset($args['meta_query'])) {
        $post_args['meta_query'] = $args['meta_query'];
    }
    
    return get_posts($post_args);
}

/**
 * Update order with HPOS compatibility
 */
function wc1c_update_order($order_id, $data) {
    $order = wc_get_order($order_id);
    if (!$order) return false;
    
    foreach ($data as $key => $value) {
        switch ($key) {
            case 'status':
                $order->set_status($value);
                break;
            case 'customer_note':
                $order->set_customer_note($value);
                break;
            default:
                $order->update_meta_data($key, $value);
                break;
        }
    }
    
    return $order->save();
}

/**
 * Get order meta with HPOS compatibility
 */
function wc1c_get_order_meta($order_id, $key, $single = true) {
    $order = wc_get_order($order_id);
    if (!$order) return false;
    
    return $order->get_meta($key, $single);
}

/**
 * Update order meta with HPOS compatibility
 */
function wc1c_update_order_meta($order_id, $key, $value) {
    $order = wc_get_order($order_id);
    if (!$order) return false;
    
    $order->update_meta_data($key, $value);
    return $order->save();
}
